from unittest import TestCase

from packagingapp.tools.full_packaging.flow_summary import build_packaging_flow_summary


class PackagingFlowSummaryTests(TestCase):
    def test_box_pallet_transport_chain(self):
        steps = [
            {
                "type": "container",
                "pending_result": {
                    "units_per_parent": 50,
                    "total_base_units": 50,
                },
            },
            {
                "type": "pallet",
                "pending_result": {
                    "units_per_parent": 60,
                    "total_base_units": 3000,
                },
            },
            {
                "type": "transport",
                "pending_result": {
                    "units_per_parent": 25,
                    "total_base_units": 75000,
                },
            },
        ]

        summary = build_packaging_flow_summary(steps)

        self.assertTrue(summary["is_complete"])
        self.assertEqual(summary["final"]["value"], "75,000")
        self.assertEqual(summary["final"]["label"], "base products / transport container")
        self.assertEqual(summary["final"]["details"], "1,500 boxes · 25 pallets")
        self.assertEqual(summary["stages"][1]["secondary"][0]["value"], "3,000")
        self.assertEqual(summary["stages"][2]["secondary"][0]["value"], "1,500")

    def test_bag_box_pallet_chain_uses_selected_fallback(self):
        steps = [
            {
                "type": "bag",
                "selected": {
                    "units_per_parent": "12",
                    "total_base_units": "12",
                },
            },
            {
                "type": "container",
                "selected": {
                    "units_per_parent": "8",
                    "total_base_units": "96",
                },
            },
            {
                "type": "pallet",
                "selected": {
                    "units_per_parent": "50",
                    "total_base_units": "4800",
                },
            },
        ]

        summary = build_packaging_flow_summary(steps)

        self.assertEqual(summary["final"]["value"], "4,800")
        self.assertEqual(summary["final"]["details"], "400 bags · 50 boxes")

    def test_incomplete_step_stops_later_multiplication(self):
        steps = [
            {
                "type": "container",
                "pending_result": {
                    "units_per_parent": 50,
                    "total_base_units": 50,
                },
            },
            {"type": "pallet", "pending_result": None},
            {
                "type": "transport",
                "pending_result": {
                    "units_per_parent": 25,
                    "total_base_units": 1250,
                },
            },
        ]

        summary = build_packaging_flow_summary(steps)

        self.assertFalse(summary["is_complete"])
        self.assertEqual(summary["completed_count"], 1)
        self.assertEqual(summary["final"]["value"], "50")
        self.assertEqual(summary["stages"][1]["status"], "Not calculated")
        self.assertEqual(summary["stages"][2]["status"], "Not calculated")

    def test_inconsistent_cumulative_payload_fails_closed(self):
        steps = [
            {
                "type": "container",
                "pending_result": {
                    "units_per_parent": 50,
                    "total_base_units": 50,
                },
            },
            {
                "type": "pallet",
                "pending_result": {
                    "units_per_parent": 60,
                    "total_base_units": 2999,
                },
            },
        ]

        summary = build_packaging_flow_summary(steps)

        self.assertEqual(summary["completed_count"], 1)
        self.assertEqual(summary["stages"][1]["status"], "Quantity chain unavailable")
        self.assertEqual(summary["final"]["value"], "50")
