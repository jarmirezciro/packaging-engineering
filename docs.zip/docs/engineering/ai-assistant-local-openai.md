# Local OpenAI assistant provider pilot

## Scope

This guide covers the Session 6 local provider pilot and the Session 7
authenticated ask endpoint. It does not approve production external AI,
configure Railway, or add the visible assistant UI. The command and opt-in
tests below make an external request only after explicit invocation and only
through KolliPack's normal readiness, Redis throttle, provider, and Assistant
Response validation path.

## Request contract

The local provider uses the OpenAI Responses API through the official Python
SDK `openai==3.24.0`:

```text
ExternalAssistantRequest
        ↓
OpenAI Responses API
        ↓
strict text.format JSON Schema
        ↓
untrusted provider candidate
        ↓
KolliPack Assistant Response 1.0 validation
```

Each call sets `store=false`, uses a server-configured model, applies the
application timeout, sets a 1,000-token default maximum output, and disables SDK
retries with `max_retries=0`. No OpenAI tools, function calls, web search,
conversation object, `previous_response_id`, or assistant/thread state is used.
Usage metadata is ignored in this pilot.

The request input contains only:

- versioned application instructions (`read_only/v1`);
- the current validated user question;
- canonical JSON for the current validated Tool Context.

The Tool Context is supplied in a separate developer-role input item and is
explicitly labeled as data. The user question is a separate user-role item.

Identity, email, username, session and CSRF values, database and owner IDs,
private catalogue names, part numbers and descriptions, file paths, scenes,
placements, full workflow state, Redis keys, and API credentials are excluded
from prompt/input data. The OpenAI API key is used only by the SDK as a
transport credential.

## Install local dependencies

Use the project's normal environment:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Start a local Redis service

Use an existing local Redis installation, or optionally start a disposable
development container:

```powershell
docker run --name kollipack-local-redis -p 6379:6379 redis:8-alpine
```

Docker is not a KolliPack runtime dependency. On a Windows development machine
without Docker or WSL, the local pilot was also verified with the portable
Redis for Windows package available through `winget`:

```powershell
winget install --id taizod1024.redis-windows-fork --exact --scope user `
  --silent --accept-package-agreements --accept-source-agreements

# Open a new PowerShell after installation so the command alias is available.
$redisServer = (Get-Command redis-server.exe).Source
Start-Process -FilePath $redisServer `
  -ArgumentList '--port 6379 --bind 127.0.0.1 --protected-mode yes --save "" --appendonly no' `
  -WindowStyle Hidden
```

This alternative is loopback-only and non-persistent for the local pilot; it
is not a KolliPack runtime or production dependency. Configure a non-production
Redis database, for example:

```powershell
$env:REDIS_URL = "redis://127.0.0.1:6379/15"
$env:AI_ASSISTANT_THROTTLE_CACHE_ALIAS = "assistant"
```

## Configure the local provider

Set these values in the same PowerShell process that will run Django. Replace
`<compatible-model-id>` with one model available to the developer's OpenAI
project that supports Responses API Structured Outputs.

```powershell
$env:AI_EXTERNAL_PROVIDER_ENABLED = "true"
$env:AI_EXTERNAL_PROVIDER_ID = "openai"
$env:AI_EXTERNAL_PROVIDER_MODEL = "<compatible-model-id>"
$env:AI_EXTERNAL_PROVIDER_SECRET_ENV = "OPENAI_API_KEY"
$env:OPENAI_API_KEY = "<developer-secret>"
$env:AI_EXTERNAL_PROVIDER_TIMEOUT_SECONDS = "10"
$env:AI_EXTERNAL_PROVIDER_MAX_OUTPUT_TOKENS = "1000"
$env:AI_EXTERNAL_PROVIDER_REASONING_EFFORT = "low"
$env:AI_ASSISTANT_RATE_LIMIT_REQUESTS = "20"
$env:AI_ASSISTANT_RATE_LIMIT_WINDOW_SECONDS = "60"
```

`AI_EXTERNAL_PROVIDER_REASONING_EFFORT` is optional. Leave it empty for a
compatible model that does not accept reasoning-effort configuration. It is
always server-owned and is never accepted from a browser or user message.

## Record explicit local privacy acknowledgement

The readiness gate deliberately requires explicit values. The following are
local-development acknowledgements, not production legal/privacy approval:

```powershell
$env:AI_EXTERNAL_PROVIDER_PRIVACY_APPROVED = "true"
$env:AI_EXTERNAL_DISCLOSURE_POLICY_VERSION = "1.0"
$env:AI_EXTERNAL_PROVIDER_TRAINING_OPT_OUT_CONFIRMED = "true"
$env:AI_EXTERNAL_PROVIDER_RETENTION_POLICY = "openai-standard-abuse-monitoring-up-to-30-days-local-ack-v1"
$env:AI_EXTERNAL_PROVIDER_DATA_RESIDENCY_POLICY = "no-provider-region-guarantee-local-pilot-v1"
$env:AI_EXTERNAL_PROVIDER_DELETION_POLICY = "store-false-no-response-application-state-local-pilot-v1"
$env:AI_EXTERNAL_PROVIDER_INCIDENT_POLICY = "developer-local-pilot-no-production-approval-v1"
$env:AI_EXTERNAL_PROVIDER_USER_DISCLOSURE_VERSION = "developer-only-no-end-user-ui-v1"
```

OpenAI states that API data is not used to train models by default unless the
organization opts in. Standard abuse-monitoring logs may contain customer
content and are normally retained for up to 30 days. This integration sets
`store=false` to disable Responses API application-state storage, but that does
not by itself mean Zero Data Retention, no provider logging, GDPR compliance,
or EU-only processing. Zero Data Retention, Modified Abuse Monitoring, and data
residency are separate organization/project controls and are not assumed by
KolliPack. See the official OpenAI documentation for [data controls](https://developers.openai.com/api/docs/guides/your-data), [Responses API state and storage](https://developers.openai.com/api/docs/guides/migrate-to-responses), and [Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs).

## Check readiness before any real call

```powershell
.\.venv\Scripts\python.exe manage.py check_ai_readiness --smoke --require-cache
```

Do not continue unless the output includes:

```text
external_provider_readiness=ready
```

Do not bypass a different outcome. Correct the reported local prerequisite.

## Run one explicit real smoke request

```powershell
$env:KOLLIPACK_OPENAI_LOCAL_SMOKE = "1"
.\.venv\Scripts\python.exe manage.py smoke_openai_assistant
```

The command builds a safe synthetic Container calculation with KolliPack's
existing deterministic service (`200 × 100 × 80 mm` product,
`600 × 400 × 300 mm` internal container, desired quantity `20`), then sends its
validated Tool Context through the normal external policy gate. It prints only
the provider/model, question, calculation status, validated response type,
validated message, validated fact references, and review flags. It never prints
the API key or raw OpenAI response.

## Run the opt-in live test or evaluation set

Ordinary tests never call OpenAI. To run the opt-in live integration tests:

```powershell
$env:KOLLIPACK_TEST_OPENAI_LIVE = "1"
.\.venv\Scripts\python.exe manage.py test packagingapp.tests.test_openai_live_integration
```

To run all 11 initial engineering questions through the same gate:

```powershell
.\.venv\Scripts\python.exe manage.py smoke_openai_assistant --evaluation
```

The live module covers both the provider-level full gate and a real
authenticated, CSRF-protected `POST /assistant/ask/` request. The endpoint test
first creates a normal complete Container result, then asks `Explain this
result.` so it verifies fresh server reconstruction, policy, Redis, OpenAI, and
final Assistant Response validation together. It prints no credential or raw
provider object.

The evaluation covers empty, partial, invalid, ready, complete, capacity,
utilization, thickness assumption, informational payload, stale, and
unsupported stacking-safety questions. Configure at least 11 requests in the
current rate window before running it; the command never bypasses the throttle.
Review the validated answers and `grounding_flags` for invented global
optimality, payload constraints, strength/protection/manufacturing conclusions,
rejected-candidate causes, orientation sensitivity, or unsupported limiting
constraints.
